#pragma once

#include <iostream>
#include <vector>

#include "Color.h"
#include "Graph.h"
#include "Course.h"

using namespace std;

void graph_coloring_bfs(Color* to_color)
{
	
}